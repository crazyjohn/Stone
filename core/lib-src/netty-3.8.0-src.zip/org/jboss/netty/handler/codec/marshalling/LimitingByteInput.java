/*
 * Copyright 2012 The Netty Project
 *
 * The Netty Project licenses this file to you under the Apache License,
 * version 2.0 (the "License"); you may not use this file except in compliance
 * with the License. You may obtain a copy of the License at:
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS, WITHOUT
 * WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied. See the
 * License for the specific language governing permissions and limitations
 * under the License.
 */
package org.jboss.netty.handler.codec.marshalling;

import java.io.IOException;

import org.jboss.marshalling.ByteInput;

/**
 * {@link ByteInput} implementation which wraps another {@link ByteInput} and throws a {@link TooBigObjectException}
 * if the read limit was reached.
 *
 *
 */
class LimitingByteInput implements ByteInput {

    // Use a static instance here to remove the overhead of fillStacktrace
    private static final TooBigObjectException EXCEPTION = new TooBigObjectException();

    private final ByteInput input;
    private final long limit;
    private long read;

    public LimitingByteInput(ByteInput input, long limit) {
        if (limit <= 0) {
            throw new IllegalArgumentException("The limit MUST be > 0");
        }
        this.input = input;
        this.limit = limit;
    }

    public void close() throws IOException {
        // Nothing todo
    }

    public int available() throws IOException {
        int available = input.available();
        int readable = readable(available);
        return readable;
    }

    public int read() throws IOException {
        int readable = readable(1);
        if (readable > 0) {
            int b = input.read();
            read++;
            return b;
        } else {
            throw EXCEPTION;
        }
    }

    public int read(byte[] array) throws IOException {
        return read(array, 0, array.length);
    }

    public int read(byte[] array, int offset, int length) throws IOException {
        int readable = readable(length);
        if (readable > 0) {
            int i = input.read(array, offset, readable);
            read += i;
            return i;
        } else {
            throw EXCEPTION;
        }
    }

    public long skip(long bytes) throws IOException {
        int readable = readable((int) bytes);
        if (readable > 0) {
            long i = input.skip(readable);
            read += i;
            return i;
        } else {
            throw EXCEPTION;
        }
    }

    private int readable(int length) {
        return (int) Math.min(length, limit - read);
    }

    /**
     * Exception that will get thrown if the {@link Object} is to big to unmarshall
     *
     */
    static final class TooBigObjectException extends IOException {
        private static final long serialVersionUID = 1L;
    }
}

package com.alvazan.play;

import com.alvazan.orm.api.base.NoSqlEntityManager;

public interface NoSqlInterface {
	 public NoSqlEntityManager em();

}

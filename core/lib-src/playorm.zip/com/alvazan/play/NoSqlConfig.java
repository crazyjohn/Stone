package com.alvazan.play;

import java.util.Map;

public interface NoSqlConfig {

	void configure(Map<String, Object> props);

}

package com.alvazan.orm.impl.meta.data.collections;

public interface CacheLoadCallback {

	void loadCacheIfNeeded();

}

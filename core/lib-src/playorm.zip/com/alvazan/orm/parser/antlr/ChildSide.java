package com.alvazan.orm.parser.antlr;

public enum ChildSide {
	RIGHT, LEFT;
}

package com.alvazan.orm.api.z8spi.meta;

import java.util.Map;


public interface NoSqlTypedRowProxy {

	void __cacheIndexedValues();

	Map<String, Object> __getOriginalValues();

}

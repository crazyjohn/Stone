package com.alvazan.orm.api.z8spi.meta;

public interface ViewInfo {

	DboTableMeta getTableMeta();

	String getAlias();
}

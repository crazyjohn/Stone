package com.alvazan.orm.api.z8spi;

public class SpiConstants {

	public static final String CASSANDRA_BUILDER = "nosql.cassandra.builder";
	public static final String CASSANDRA_CF_CREATE_CALLBACK = "nosql.cassandra.createcfcallback";

}

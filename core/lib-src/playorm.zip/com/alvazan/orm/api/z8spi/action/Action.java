package com.alvazan.orm.api.z8spi.action;

import com.alvazan.orm.api.z8spi.meta.DboTableMeta;

public interface Action {

	DboTableMeta getColFamily();

}

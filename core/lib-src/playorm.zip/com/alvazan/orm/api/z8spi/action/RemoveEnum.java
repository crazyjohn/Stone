package com.alvazan.orm.api.z8spi.action;

public enum RemoveEnum {
	REMOVE_ENTIRE_ROW, REMOVE_COLUMNS_FROM_ROW;
}

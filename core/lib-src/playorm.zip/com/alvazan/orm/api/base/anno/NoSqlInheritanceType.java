package com.alvazan.orm.api.base.anno;

public enum NoSqlInheritanceType {
	SINGLE_TABLE;
}

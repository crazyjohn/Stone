package com.alvazan.orm.logging;

public enum ScanType {

	FIND, COLUMN_SLICE, RANGE_SLICE, NON_CONTIGUOUS;
}

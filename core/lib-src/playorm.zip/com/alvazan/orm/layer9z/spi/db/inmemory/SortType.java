package com.alvazan.orm.layer9z.spi.db.inmemory;

public enum SortType {
	UTF8, INTEGER, DECIMAL, BYTES, UTF8_PREFIX, INTEGER_PREFIX, DECIMAL_PREFIX;
}

package org.playorm.cron.impl;

import org.joda.time.DateTime;

public interface CurrentTime {

	DateTime currentTime();

}

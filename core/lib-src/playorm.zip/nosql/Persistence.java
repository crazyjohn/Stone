package nosql;

public class Persistence {

}

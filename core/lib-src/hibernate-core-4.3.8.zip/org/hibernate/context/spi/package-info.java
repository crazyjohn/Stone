/**
 * SPI level contracts around "current session" support.
 */
package org.hibernate.context.spi;

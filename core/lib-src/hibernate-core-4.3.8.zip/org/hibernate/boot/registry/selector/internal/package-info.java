/**
 * Internals for building StrategySelector
 */
package org.hibernate.boot.registry.selector.internal;

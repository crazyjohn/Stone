/**
 * Defines a feature-set around named registration of implementations of various contracts and the ability
 * to select those implementations.
 */
package org.hibernate.boot.registry.selector;

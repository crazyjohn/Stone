/**
 * The class loading service internals.
 */
package org.hibernate.boot.registry.classloading.internal;

/**
 * The class loading service SPI.
 */
package org.hibernate.boot.registry.classloading.spi;

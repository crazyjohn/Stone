/**
 * The internals for building service registries.
 */
package org.hibernate.boot.registry.internal;

package javax.persistence;

public abstract interface Cache
{
  public abstract boolean contains(Class paramClass, Object paramObject);

  public abstract void evict(Class paramClass, Object paramObject);

  public abstract void evict(Class paramClass);

  public abstract void evictAll();

  public abstract <T> T unwrap(Class<T> paramClass);
}

/* Location:           C:\Users\Administrator\Downloads\-hibernate-release-4.3.8.Final\hibernate-release-4.3.8.Final\lib\required\hibernate-jpa-2.1-api-1.0.0.Final.jar
 * Qualified Name:     javax.persistence.Cache
 * JD-Core Version:    0.6.2
 */
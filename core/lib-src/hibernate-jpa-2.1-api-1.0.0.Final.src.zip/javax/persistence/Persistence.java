/*     */ package javax.persistence;
/*     */ 
/*     */ import java.util.HashSet;
/*     */ import java.util.List;
/*     */ import java.util.Map;
/*     */ import java.util.Set;
/*     */ import javax.persistence.spi.LoadState;
/*     */ import javax.persistence.spi.PersistenceProvider;
/*     */ import javax.persistence.spi.PersistenceProviderResolver;
/*     */ import javax.persistence.spi.PersistenceProviderResolverHolder;
/*     */ import javax.persistence.spi.ProviderUtil;
/*     */ 
/*     */ public class Persistence
/*     */ {
/*     */ 
/*     */   @Deprecated
/*     */   public static final String PERSISTENCE_PROVIDER = "javax.persistence.spi.PeristenceProvider";
/*     */ 
/*     */   @Deprecated
/*  29 */   protected static final Set<PersistenceProvider> providers = new HashSet();
/*     */ 
/* 105 */   private static PersistenceUtil util = new PersistenceUtil()
/*     */   {
/*     */     public boolean isLoaded(Object entity, String attributeName)
/*     */     {
/* 109 */       List providers = Persistence.access$000();
/* 110 */       for (PersistenceProvider provider : providers) {
/* 111 */         LoadState state = provider.getProviderUtil().isLoadedWithoutReference(entity, attributeName);
/* 112 */         if (state != LoadState.UNKNOWN)
/* 113 */           return state == LoadState.LOADED;
/*     */       }
/* 115 */       for (PersistenceProvider provider : providers) {
/* 116 */         LoadState state = provider.getProviderUtil().isLoadedWithReference(entity, attributeName);
/* 117 */         if (state != LoadState.UNKNOWN)
/* 118 */           return state == LoadState.LOADED;
/*     */       }
/* 120 */       return true;
/*     */     }
/*     */ 
/*     */     public boolean isLoaded(Object object) {
/* 124 */       List providers = Persistence.access$000();
/* 125 */       for (PersistenceProvider provider : providers) {
/* 126 */         LoadState state = provider.getProviderUtil().isLoaded(object);
/* 127 */         if (state != LoadState.UNKNOWN)
/* 128 */           return state == LoadState.LOADED;
/*     */       }
/* 130 */       return true;
/*     */     }
/* 105 */   };
/*     */ 
/*     */   public static EntityManagerFactory createEntityManagerFactory(String persistenceUnitName)
/*     */   {
/*  39 */     return createEntityManagerFactory(persistenceUnitName, null);
/*     */   }
/*     */ 
/*     */   public static EntityManagerFactory createEntityManagerFactory(String persistenceUnitName, Map properties)
/*     */   {
/*  52 */     EntityManagerFactory emf = null;
/*  53 */     List providers = getProviders();
/*  54 */     for (PersistenceProvider provider : providers) {
/*  55 */       emf = provider.createEntityManagerFactory(persistenceUnitName, properties);
/*  56 */       if (emf != null) {
/*     */         break;
/*     */       }
/*     */     }
/*  60 */     if (emf == null) {
/*  61 */       throw new PersistenceException("No Persistence provider for EntityManager named " + persistenceUnitName);
/*     */     }
/*  63 */     return emf;
/*     */   }
/*     */ 
/*     */   private static List<PersistenceProvider> getProviders()
/*     */   {
/*  69 */     return PersistenceProviderResolverHolder.getPersistenceProviderResolver()
/*  69 */       .getPersistenceProviders();
/*     */   }
/*     */ 
/*     */   public static void generateSchema(String persistenceUnitName, Map properties)
/*     */   {
/*  85 */     List providers = getProviders();
/*  86 */     for (PersistenceProvider provider : providers) {
/*  87 */       boolean generated = provider.generateSchema(persistenceUnitName, properties);
/*  88 */       if (generated) {
/*  89 */         return;
/*     */       }
/*     */     }
/*     */ 
/*  93 */     throw new PersistenceException("No persistence provider found for schema generation for persistence-unit named " + persistenceUnitName);
/*     */   }
/*     */ 
/*     */   public static PersistenceUtil getPersistenceUtil()
/*     */   {
/* 102 */     return util;
/*     */   }
/*     */ }

/* Location:           C:\Users\Administrator\Downloads\-hibernate-release-4.3.8.Final\hibernate-release-4.3.8.Final\lib\required\hibernate-jpa-2.1-api-1.0.0.Final.jar
 * Qualified Name:     javax.persistence.Persistence
 * JD-Core Version:    0.6.2
 */
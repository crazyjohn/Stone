/*    */ package javax.persistence;
/*    */ 
/*    */ public enum DiscriminatorType
/*    */ {
/* 22 */   STRING, 
/*    */ 
/* 27 */   CHAR, 
/*    */ 
/* 32 */   INTEGER;
/*    */ }

/* Location:           C:\Users\Administrator\Downloads\-hibernate-release-4.3.8.Final\hibernate-release-4.3.8.Final\lib\required\hibernate-jpa-2.1-api-1.0.0.Final.jar
 * Qualified Name:     javax.persistence.DiscriminatorType
 * JD-Core Version:    0.6.2
 */
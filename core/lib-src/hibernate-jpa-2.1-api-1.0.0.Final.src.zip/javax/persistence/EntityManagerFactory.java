package javax.persistence;

import java.util.Map;
import javax.persistence.criteria.CriteriaBuilder;
import javax.persistence.metamodel.Metamodel;

public abstract interface EntityManagerFactory
{
  public abstract EntityManager createEntityManager();

  public abstract EntityManager createEntityManager(Map paramMap);

  public abstract EntityManager createEntityManager(SynchronizationType paramSynchronizationType);

  public abstract EntityManager createEntityManager(SynchronizationType paramSynchronizationType, Map paramMap);

  public abstract CriteriaBuilder getCriteriaBuilder();

  public abstract Metamodel getMetamodel();

  public abstract boolean isOpen();

  public abstract void close();

  public abstract Map<String, Object> getProperties();

  public abstract Cache getCache();

  public abstract PersistenceUnitUtil getPersistenceUnitUtil();

  public abstract void addNamedQuery(String paramString, Query paramQuery);

  public abstract <T> T unwrap(Class<T> paramClass);

  public abstract <T> void addNamedEntityGraph(String paramString, EntityGraph<T> paramEntityGraph);
}

/* Location:           C:\Users\Administrator\Downloads\-hibernate-release-4.3.8.Final\hibernate-release-4.3.8.Final\lib\required\hibernate-jpa-2.1-api-1.0.0.Final.jar
 * Qualified Name:     javax.persistence.EntityManagerFactory
 * JD-Core Version:    0.6.2
 */
/*    */ package javax.persistence;
/*    */ 
/*    */ public enum ConstraintMode
/*    */ {
/* 21 */   CONSTRAINT, 
/*    */ 
/* 25 */   NO_CONSTRAINT, 
/*    */ 
/* 29 */   PROVIDER_DEFAULT;
/*    */ }

/* Location:           C:\Users\Administrator\Downloads\-hibernate-release-4.3.8.Final\hibernate-release-4.3.8.Final\lib\required\hibernate-jpa-2.1-api-1.0.0.Final.jar
 * Qualified Name:     javax.persistence.ConstraintMode
 * JD-Core Version:    0.6.2
 */
/*    */ package javax.persistence;
/*    */ 
/*    */ public class LockTimeoutException extends PersistenceException
/*    */ {
/*    */   Object entity;
/*    */ 
/*    */   public LockTimeoutException()
/*    */   {
/*    */   }
/*    */ 
/*    */   public LockTimeoutException(String message)
/*    */   {
/* 39 */     super(message);
/*    */   }
/*    */ 
/*    */   public LockTimeoutException(String message, Throwable cause)
/*    */   {
/* 49 */     super(message, cause);
/*    */   }
/*    */ 
/*    */   public LockTimeoutException(Throwable cause)
/*    */   {
/* 58 */     super(cause);
/*    */   }
/*    */ 
/*    */   public LockTimeoutException(Object entity)
/*    */   {
/* 67 */     this.entity = entity;
/*    */   }
/*    */ 
/*    */   public LockTimeoutException(String message, Throwable cause, Object entity)
/*    */   {
/* 78 */     super(message, cause);
/* 79 */     this.entity = entity;
/*    */   }
/*    */ 
/*    */   public Object getObject()
/*    */   {
/* 87 */     return this.entity;
/*    */   }
/*    */ }

/* Location:           C:\Users\Administrator\Downloads\-hibernate-release-4.3.8.Final\hibernate-release-4.3.8.Final\lib\required\hibernate-jpa-2.1-api-1.0.0.Final.jar
 * Qualified Name:     javax.persistence.LockTimeoutException
 * JD-Core Version:    0.6.2
 */
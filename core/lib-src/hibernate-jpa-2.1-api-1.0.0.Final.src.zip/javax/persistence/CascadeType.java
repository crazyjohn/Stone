/*    */ package javax.persistence;
/*    */ 
/*    */ public enum CascadeType
/*    */ {
/* 23 */   ALL, 
/*    */ 
/* 26 */   PERSIST, 
/*    */ 
/* 29 */   MERGE, 
/*    */ 
/* 32 */   REMOVE, 
/*    */ 
/* 35 */   REFRESH, 
/*    */ 
/* 43 */   DETACH;
/*    */ }

/* Location:           C:\Users\Administrator\Downloads\-hibernate-release-4.3.8.Final\hibernate-release-4.3.8.Final\lib\required\hibernate-jpa-2.1-api-1.0.0.Final.jar
 * Qualified Name:     javax.persistence.CascadeType
 * JD-Core Version:    0.6.2
 */
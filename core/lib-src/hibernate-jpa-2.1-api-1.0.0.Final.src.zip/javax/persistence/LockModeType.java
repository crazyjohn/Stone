/*     */ package javax.persistence;
/*     */ 
/*     */ public enum LockModeType
/*     */ {
/* 128 */   READ, 
/*     */ 
/* 136 */   WRITE, 
/*     */ 
/* 143 */   OPTIMISTIC, 
/*     */ 
/* 150 */   OPTIMISTIC_FORCE_INCREMENT, 
/*     */ 
/* 158 */   PESSIMISTIC_READ, 
/*     */ 
/* 165 */   PESSIMISTIC_WRITE, 
/*     */ 
/* 172 */   PESSIMISTIC_FORCE_INCREMENT, 
/*     */ 
/* 179 */   NONE;
/*     */ }

/* Location:           C:\Users\Administrator\Downloads\-hibernate-release-4.3.8.Final\hibernate-release-4.3.8.Final\lib\required\hibernate-jpa-2.1-api-1.0.0.Final.jar
 * Qualified Name:     javax.persistence.LockModeType
 * JD-Core Version:    0.6.2
 */
/*    */ package javax.persistence;
/*    */ 
/*    */ public enum SynchronizationType
/*    */ {
/* 21 */   SYNCHRONIZED, 
/*    */ 
/* 34 */   UNSYNCHRONIZED;
/*    */ }

/* Location:           C:\Users\Administrator\Downloads\-hibernate-release-4.3.8.Final\hibernate-release-4.3.8.Final\lib\required\hibernate-jpa-2.1-api-1.0.0.Final.jar
 * Qualified Name:     javax.persistence.SynchronizationType
 * JD-Core Version:    0.6.2
 */
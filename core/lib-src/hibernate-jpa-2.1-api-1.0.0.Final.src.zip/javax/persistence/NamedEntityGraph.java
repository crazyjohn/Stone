package javax.persistence;

import java.lang.annotation.Annotation;
import java.lang.annotation.Retention;
import java.lang.annotation.RetentionPolicy;
import java.lang.annotation.Target;

@Target({java.lang.annotation.ElementType.TYPE})
@Retention(RetentionPolicy.RUNTIME)
public @interface NamedEntityGraph
{
  public abstract String name();

  public abstract NamedAttributeNode[] attributeNodes();

  public abstract boolean includeAllAttributes();

  public abstract NamedSubgraph[] subgraphs();

  public abstract NamedSubgraph[] subclassSubgraphs();
}

/* Location:           C:\Users\Administrator\Downloads\-hibernate-release-4.3.8.Final\hibernate-release-4.3.8.Final\lib\required\hibernate-jpa-2.1-api-1.0.0.Final.jar
 * Qualified Name:     javax.persistence.NamedEntityGraph
 * JD-Core Version:    0.6.2
 */
package javax.persistence;

import java.util.List;
import javax.persistence.metamodel.Attribute;

public abstract interface Subgraph<T>
{
  public abstract void addAttributeNodes(String[] paramArrayOfString);

  public abstract void addAttributeNodes(Attribute<T, ?>[] paramArrayOfAttribute);

  public abstract <X> Subgraph<X> addSubgraph(Attribute<T, X> paramAttribute);

  public abstract <X> Subgraph<? extends X> addSubgraph(Attribute<T, X> paramAttribute, Class<? extends X> paramClass);

  public abstract <X> Subgraph<X> addSubgraph(String paramString);

  public abstract <X> Subgraph<X> addSubgraph(String paramString, Class<X> paramClass);

  public abstract <X> Subgraph<X> addKeySubgraph(Attribute<T, X> paramAttribute);

  public abstract <X> Subgraph<? extends X> addKeySubgraph(Attribute<T, X> paramAttribute, Class<? extends X> paramClass);

  public abstract <X> Subgraph<X> addKeySubgraph(String paramString);

  public abstract <X> Subgraph<X> addKeySubgraph(String paramString, Class<X> paramClass);

  public abstract List<AttributeNode<?>> getAttributeNodes();

  public abstract Class<T> getClassType();
}

/* Location:           C:\Users\Administrator\Downloads\-hibernate-release-4.3.8.Final\hibernate-release-4.3.8.Final\lib\required\hibernate-jpa-2.1-api-1.0.0.Final.jar
 * Qualified Name:     javax.persistence.Subgraph
 * JD-Core Version:    0.6.2
 */
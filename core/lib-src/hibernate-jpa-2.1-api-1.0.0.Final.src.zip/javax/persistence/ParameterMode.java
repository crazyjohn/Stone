/*    */ package javax.persistence;
/*    */ 
/*    */ public enum ParameterMode
/*    */ {
/* 24 */   IN, 
/*    */ 
/* 28 */   INOUT, 
/*    */ 
/* 32 */   OUT, 
/*    */ 
/* 36 */   REF_CURSOR;
/*    */ }

/* Location:           C:\Users\Administrator\Downloads\-hibernate-release-4.3.8.Final\hibernate-release-4.3.8.Final\lib\required\hibernate-jpa-2.1-api-1.0.0.Final.jar
 * Qualified Name:     javax.persistence.ParameterMode
 * JD-Core Version:    0.6.2
 */
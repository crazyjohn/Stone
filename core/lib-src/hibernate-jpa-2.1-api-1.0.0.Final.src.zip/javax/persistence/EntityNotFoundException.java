/*    */ package javax.persistence;
/*    */ 
/*    */ public class EntityNotFoundException extends PersistenceException
/*    */ {
/*    */   public EntityNotFoundException()
/*    */   {
/*    */   }
/*    */ 
/*    */   public EntityNotFoundException(String message)
/*    */   {
/* 50 */     super(message);
/*    */   }
/*    */ }

/* Location:           C:\Users\Administrator\Downloads\-hibernate-release-4.3.8.Final\hibernate-release-4.3.8.Final\lib\required\hibernate-jpa-2.1-api-1.0.0.Final.jar
 * Qualified Name:     javax.persistence.EntityNotFoundException
 * JD-Core Version:    0.6.2
 */
/*    */ package javax.persistence;
/*    */ 
/*    */ public enum SharedCacheMode
/*    */ {
/* 24 */   ALL, 
/*    */ 
/* 29 */   NONE, 
/*    */ 
/* 35 */   ENABLE_SELECTIVE, 
/*    */ 
/* 42 */   DISABLE_SELECTIVE, 
/*    */ 
/* 48 */   UNSPECIFIED;
/*    */ }

/* Location:           C:\Users\Administrator\Downloads\-hibernate-release-4.3.8.Final\hibernate-release-4.3.8.Final\lib\required\hibernate-jpa-2.1-api-1.0.0.Final.jar
 * Qualified Name:     javax.persistence.SharedCacheMode
 * JD-Core Version:    0.6.2
 */
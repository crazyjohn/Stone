/*    */ package javax.persistence.metamodel;
/*    */ 
/*    */ import java.lang.reflect.Member;
/*    */ 
/*    */ public abstract interface Attribute<X, Y>
/*    */ {
/*    */   public abstract String getName();
/*    */ 
/*    */   public abstract PersistentAttributeType getPersistentAttributeType();
/*    */ 
/*    */   public abstract ManagedType<X> getDeclaringType();
/*    */ 
/*    */   public abstract Class<Y> getJavaType();
/*    */ 
/*    */   public abstract Member getJavaMember();
/*    */ 
/*    */   public abstract boolean isAssociation();
/*    */ 
/*    */   public abstract boolean isCollection();
/*    */ 
/*    */   public static enum PersistentAttributeType
/*    */   {
/* 24 */     MANY_TO_ONE, 
/*    */ 
/* 29 */     ONE_TO_ONE, 
/*    */ 
/* 34 */     BASIC, 
/*    */ 
/* 39 */     EMBEDDED, 
/*    */ 
/* 44 */     MANY_TO_MANY, 
/*    */ 
/* 49 */     ONE_TO_MANY, 
/*    */ 
/* 54 */     ELEMENT_COLLECTION;
/*    */   }
/*    */ }

/* Location:           C:\Users\Administrator\Downloads\-hibernate-release-4.3.8.Final\hibernate-release-4.3.8.Final\lib\required\hibernate-jpa-2.1-api-1.0.0.Final.jar
 * Qualified Name:     javax.persistence.metamodel.Attribute
 * JD-Core Version:    0.6.2
 */
package javax.persistence.metamodel;

public abstract interface SingularAttribute<X, T> extends Attribute<X, T>, Bindable<T>
{
  public abstract boolean isId();

  public abstract boolean isVersion();

  public abstract boolean isOptional();

  public abstract Type<T> getType();
}

/* Location:           C:\Users\Administrator\Downloads\-hibernate-release-4.3.8.Final\hibernate-release-4.3.8.Final\lib\required\hibernate-jpa-2.1-api-1.0.0.Final.jar
 * Qualified Name:     javax.persistence.metamodel.SingularAttribute
 * JD-Core Version:    0.6.2
 */
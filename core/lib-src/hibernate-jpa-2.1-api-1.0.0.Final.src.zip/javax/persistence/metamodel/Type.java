/*    */ package javax.persistence.metamodel;
/*    */ 
/*    */ public abstract interface Type<X>
/*    */ {
/*    */   public abstract PersistenceType getPersistenceType();
/*    */ 
/*    */   public abstract Class<X> getJavaType();
/*    */ 
/*    */   public static enum PersistenceType
/*    */   {
/* 24 */     ENTITY, 
/*    */ 
/* 29 */     EMBEDDABLE, 
/*    */ 
/* 34 */     MAPPED_SUPERCLASS, 
/*    */ 
/* 39 */     BASIC;
/*    */   }
/*    */ }

/* Location:           C:\Users\Administrator\Downloads\-hibernate-release-4.3.8.Final\hibernate-release-4.3.8.Final\lib\required\hibernate-jpa-2.1-api-1.0.0.Final.jar
 * Qualified Name:     javax.persistence.metamodel.Type
 * JD-Core Version:    0.6.2
 */
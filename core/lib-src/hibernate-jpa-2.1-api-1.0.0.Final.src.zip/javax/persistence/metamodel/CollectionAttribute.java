package javax.persistence.metamodel;

import java.util.Collection;

public abstract interface CollectionAttribute<X, E> extends PluralAttribute<X, Collection<E>, E>
{
}

/* Location:           C:\Users\Administrator\Downloads\-hibernate-release-4.3.8.Final\hibernate-release-4.3.8.Final\lib\required\hibernate-jpa-2.1-api-1.0.0.Final.jar
 * Qualified Name:     javax.persistence.metamodel.CollectionAttribute
 * JD-Core Version:    0.6.2
 */
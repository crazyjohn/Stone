/*    */ package javax.persistence.metamodel;
/*    */ 
/*    */ public abstract interface PluralAttribute<X, C, E> extends Attribute<X, C>, Bindable<E>
/*    */ {
/*    */   public abstract CollectionType getCollectionType();
/*    */ 
/*    */   public abstract Type<E> getElementType();
/*    */ 
/*    */   public static enum CollectionType
/*    */   {
/* 26 */     COLLECTION, 
/*    */ 
/* 31 */     SET, 
/*    */ 
/* 36 */     LIST, 
/*    */ 
/* 41 */     MAP;
/*    */   }
/*    */ }

/* Location:           C:\Users\Administrator\Downloads\-hibernate-release-4.3.8.Final\hibernate-release-4.3.8.Final\lib\required\hibernate-jpa-2.1-api-1.0.0.Final.jar
 * Qualified Name:     javax.persistence.metamodel.PluralAttribute
 * JD-Core Version:    0.6.2
 */
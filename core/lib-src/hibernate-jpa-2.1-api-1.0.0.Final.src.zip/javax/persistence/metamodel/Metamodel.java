package javax.persistence.metamodel;

import java.util.Set;

public abstract interface Metamodel
{
  public abstract <X> EntityType<X> entity(Class<X> paramClass);

  public abstract <X> ManagedType<X> managedType(Class<X> paramClass);

  public abstract <X> EmbeddableType<X> embeddable(Class<X> paramClass);

  public abstract Set<ManagedType<?>> getManagedTypes();

  public abstract Set<EntityType<?>> getEntities();

  public abstract Set<EmbeddableType<?>> getEmbeddables();
}

/* Location:           C:\Users\Administrator\Downloads\-hibernate-release-4.3.8.Final\hibernate-release-4.3.8.Final\lib\required\hibernate-jpa-2.1-api-1.0.0.Final.jar
 * Qualified Name:     javax.persistence.metamodel.Metamodel
 * JD-Core Version:    0.6.2
 */
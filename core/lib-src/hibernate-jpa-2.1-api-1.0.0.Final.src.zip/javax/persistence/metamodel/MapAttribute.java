package javax.persistence.metamodel;

import java.util.Map;

public abstract interface MapAttribute<X, K, V> extends PluralAttribute<X, Map<K, V>, V>
{
  public abstract Class<K> getKeyJavaType();

  public abstract Type<K> getKeyType();
}

/* Location:           C:\Users\Administrator\Downloads\-hibernate-release-4.3.8.Final\hibernate-release-4.3.8.Final\lib\required\hibernate-jpa-2.1-api-1.0.0.Final.jar
 * Qualified Name:     javax.persistence.metamodel.MapAttribute
 * JD-Core Version:    0.6.2
 */
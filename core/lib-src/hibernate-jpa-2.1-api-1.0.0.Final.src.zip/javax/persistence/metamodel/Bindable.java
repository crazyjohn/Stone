/*    */ package javax.persistence.metamodel;
/*    */ 
/*    */ public abstract interface Bindable<T>
/*    */ {
/*    */   public abstract BindableType getBindableType();
/*    */ 
/*    */   public abstract Class<T> getBindableJavaType();
/*    */ 
/*    */   public static enum BindableType
/*    */   {
/* 24 */     SINGULAR_ATTRIBUTE, 
/*    */ 
/* 29 */     PLURAL_ATTRIBUTE, 
/*    */ 
/* 34 */     ENTITY_TYPE;
/*    */   }
/*    */ }

/* Location:           C:\Users\Administrator\Downloads\-hibernate-release-4.3.8.Final\hibernate-release-4.3.8.Final\lib\required\hibernate-jpa-2.1-api-1.0.0.Final.jar
 * Qualified Name:     javax.persistence.metamodel.Bindable
 * JD-Core Version:    0.6.2
 */
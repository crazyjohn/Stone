package javax.persistence.criteria;

import java.util.List;
import java.util.Set;
import javax.persistence.metamodel.EntityType;

public abstract interface AbstractQuery<T> extends CommonAbstractCriteria
{
  public abstract <X> Root<X> from(Class<X> paramClass);

  public abstract <X> Root<X> from(EntityType<X> paramEntityType);

  public abstract AbstractQuery<T> where(Expression<Boolean> paramExpression);

  public abstract AbstractQuery<T> where(Predicate[] paramArrayOfPredicate);

  public abstract AbstractQuery<T> groupBy(Expression<?>[] paramArrayOfExpression);

  public abstract AbstractQuery<T> groupBy(List<Expression<?>> paramList);

  public abstract AbstractQuery<T> having(Expression<Boolean> paramExpression);

  public abstract AbstractQuery<T> having(Predicate[] paramArrayOfPredicate);

  public abstract AbstractQuery<T> distinct(boolean paramBoolean);

  public abstract Set<Root<?>> getRoots();

  public abstract Selection<T> getSelection();

  public abstract List<Expression<?>> getGroupList();

  public abstract Predicate getGroupRestriction();

  public abstract boolean isDistinct();

  public abstract Class<T> getResultType();
}

/* Location:           C:\Users\Administrator\Downloads\-hibernate-release-4.3.8.Final\hibernate-release-4.3.8.Final\lib\required\hibernate-jpa-2.1-api-1.0.0.Final.jar
 * Qualified Name:     javax.persistence.criteria.AbstractQuery
 * JD-Core Version:    0.6.2
 */
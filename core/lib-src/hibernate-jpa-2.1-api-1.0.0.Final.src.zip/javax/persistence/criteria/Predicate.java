/*    */ package javax.persistence.criteria;
/*    */ 
/*    */ import java.util.List;
/*    */ 
/*    */ public abstract interface Predicate extends Expression<Boolean>
/*    */ {
/*    */   public abstract BooleanOperator getOperator();
/*    */ 
/*    */   public abstract boolean isNegated();
/*    */ 
/*    */   public abstract List<Expression<Boolean>> getExpressions();
/*    */ 
/*    */   public abstract Predicate not();
/*    */ 
/*    */   public static enum BooleanOperator
/*    */   {
/* 25 */     AND, 
/* 26 */     OR;
/*    */   }
/*    */ }

/* Location:           C:\Users\Administrator\Downloads\-hibernate-release-4.3.8.Final\hibernate-release-4.3.8.Final\lib\required\hibernate-jpa-2.1-api-1.0.0.Final.jar
 * Qualified Name:     javax.persistence.criteria.Predicate
 * JD-Core Version:    0.6.2
 */
package javax.persistence.criteria;

import java.util.Collection;
import java.util.Map;
import javax.persistence.metamodel.Bindable;
import javax.persistence.metamodel.MapAttribute;
import javax.persistence.metamodel.PluralAttribute;
import javax.persistence.metamodel.SingularAttribute;

public abstract interface Path<X> extends Expression<X>
{
  public abstract Bindable<X> getModel();

  public abstract Path<?> getParentPath();

  public abstract <Y> Path<Y> get(SingularAttribute<? super X, Y> paramSingularAttribute);

  public abstract <E, C extends Collection<E>> Expression<C> get(PluralAttribute<X, C, E> paramPluralAttribute);

  public abstract <K, V, M extends Map<K, V>> Expression<M> get(MapAttribute<X, K, V> paramMapAttribute);

  public abstract Expression<Class<? extends X>> type();

  public abstract <Y> Path<Y> get(String paramString);
}

/* Location:           C:\Users\Administrator\Downloads\-hibernate-release-4.3.8.Final\hibernate-release-4.3.8.Final\lib\required\hibernate-jpa-2.1-api-1.0.0.Final.jar
 * Qualified Name:     javax.persistence.criteria.Path
 * JD-Core Version:    0.6.2
 */
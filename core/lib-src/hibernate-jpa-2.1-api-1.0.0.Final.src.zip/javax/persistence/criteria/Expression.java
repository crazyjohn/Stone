package javax.persistence.criteria;

import java.util.Collection;

public abstract interface Expression<T> extends Selection<T>
{
  public abstract Predicate isNull();

  public abstract Predicate isNotNull();

  public abstract Predicate in(Object[] paramArrayOfObject);

  public abstract Predicate in(Expression<?>[] paramArrayOfExpression);

  public abstract Predicate in(Collection<?> paramCollection);

  public abstract Predicate in(Expression<Collection<?>> paramExpression);

  public abstract <X> Expression<X> as(Class<X> paramClass);
}

/* Location:           C:\Users\Administrator\Downloads\-hibernate-release-4.3.8.Final\hibernate-release-4.3.8.Final\lib\required\hibernate-jpa-2.1-api-1.0.0.Final.jar
 * Qualified Name:     javax.persistence.criteria.Expression
 * JD-Core Version:    0.6.2
 */
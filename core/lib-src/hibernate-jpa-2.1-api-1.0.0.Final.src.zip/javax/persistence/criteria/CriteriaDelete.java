package javax.persistence.criteria;

import javax.persistence.metamodel.EntityType;

public abstract interface CriteriaDelete<T> extends CommonAbstractCriteria
{
  public abstract Root<T> from(Class<T> paramClass);

  public abstract Root<T> from(EntityType<T> paramEntityType);

  public abstract Root<T> getRoot();

  public abstract CriteriaDelete<T> where(Expression<Boolean> paramExpression);

  public abstract CriteriaDelete<T> where(Predicate[] paramArrayOfPredicate);
}

/* Location:           C:\Users\Administrator\Downloads\-hibernate-release-4.3.8.Final\hibernate-release-4.3.8.Final\lib\required\hibernate-jpa-2.1-api-1.0.0.Final.jar
 * Qualified Name:     javax.persistence.criteria.CriteriaDelete
 * JD-Core Version:    0.6.2
 */
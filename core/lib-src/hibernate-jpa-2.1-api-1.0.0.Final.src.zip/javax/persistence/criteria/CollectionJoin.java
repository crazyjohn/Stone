package javax.persistence.criteria;

import java.util.Collection;
import javax.persistence.metamodel.CollectionAttribute;

public abstract interface CollectionJoin<Z, E> extends PluralJoin<Z, Collection<E>, E>
{
  public abstract CollectionJoin<Z, E> on(Expression<Boolean> paramExpression);

  public abstract CollectionJoin<Z, E> on(Predicate[] paramArrayOfPredicate);

  public abstract CollectionAttribute<? super Z, E> getModel();
}

/* Location:           C:\Users\Administrator\Downloads\-hibernate-release-4.3.8.Final\hibernate-release-4.3.8.Final\lib\required\hibernate-jpa-2.1-api-1.0.0.Final.jar
 * Qualified Name:     javax.persistence.criteria.CollectionJoin
 * JD-Core Version:    0.6.2
 */
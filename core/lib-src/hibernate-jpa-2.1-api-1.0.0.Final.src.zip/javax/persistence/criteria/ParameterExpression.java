package javax.persistence.criteria;

import javax.persistence.Parameter;

public abstract interface ParameterExpression<T> extends Parameter<T>, Expression<T>
{
}

/* Location:           C:\Users\Administrator\Downloads\-hibernate-release-4.3.8.Final\hibernate-release-4.3.8.Final\lib\required\hibernate-jpa-2.1-api-1.0.0.Final.jar
 * Qualified Name:     javax.persistence.criteria.ParameterExpression
 * JD-Core Version:    0.6.2
 */
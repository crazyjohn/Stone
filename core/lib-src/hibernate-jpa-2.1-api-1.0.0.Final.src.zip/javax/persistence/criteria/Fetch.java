package javax.persistence.criteria;

import javax.persistence.metamodel.Attribute;

public abstract interface Fetch<Z, X> extends FetchParent<Z, X>
{
  public abstract Attribute<? super Z, ?> getAttribute();

  public abstract FetchParent<?, Z> getParent();

  public abstract JoinType getJoinType();
}

/* Location:           C:\Users\Administrator\Downloads\-hibernate-release-4.3.8.Final\hibernate-release-4.3.8.Final\lib\required\hibernate-jpa-2.1-api-1.0.0.Final.jar
 * Qualified Name:     javax.persistence.criteria.Fetch
 * JD-Core Version:    0.6.2
 */
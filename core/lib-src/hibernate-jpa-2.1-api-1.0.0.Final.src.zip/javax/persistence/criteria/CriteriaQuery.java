package javax.persistence.criteria;

import java.util.List;
import java.util.Set;

public abstract interface CriteriaQuery<T> extends AbstractQuery<T>
{
  public abstract CriteriaQuery<T> select(Selection<? extends T> paramSelection);

  public abstract CriteriaQuery<T> multiselect(Selection<?>[] paramArrayOfSelection);

  public abstract CriteriaQuery<T> multiselect(List<Selection<?>> paramList);

  public abstract CriteriaQuery<T> where(Expression<Boolean> paramExpression);

  public abstract CriteriaQuery<T> where(Predicate[] paramArrayOfPredicate);

  public abstract CriteriaQuery<T> groupBy(Expression<?>[] paramArrayOfExpression);

  public abstract CriteriaQuery<T> groupBy(List<Expression<?>> paramList);

  public abstract CriteriaQuery<T> having(Expression<Boolean> paramExpression);

  public abstract CriteriaQuery<T> having(Predicate[] paramArrayOfPredicate);

  public abstract CriteriaQuery<T> orderBy(Order[] paramArrayOfOrder);

  public abstract CriteriaQuery<T> orderBy(List<Order> paramList);

  public abstract CriteriaQuery<T> distinct(boolean paramBoolean);

  public abstract List<Order> getOrderList();

  public abstract Set<ParameterExpression<?>> getParameters();
}

/* Location:           C:\Users\Administrator\Downloads\-hibernate-release-4.3.8.Final\hibernate-release-4.3.8.Final\lib\required\hibernate-jpa-2.1-api-1.0.0.Final.jar
 * Qualified Name:     javax.persistence.criteria.CriteriaQuery
 * JD-Core Version:    0.6.2
 */
/*      */ package javax.persistence.criteria;
/*      */ 
/*      */ import java.math.BigDecimal;
/*      */ import java.math.BigInteger;
/*      */ import java.sql.Date;
/*      */ import java.sql.Time;
/*      */ import java.sql.Timestamp;
/*      */ import java.util.Collection;
/*      */ import java.util.Map;
/*      */ import java.util.Set;
/*      */ import javax.persistence.Tuple;
/*      */ 
/*      */ public abstract interface CriteriaBuilder
/*      */ {
/*      */   public abstract CriteriaQuery<Object> createQuery();
/*      */ 
/*      */   public abstract <T> CriteriaQuery<T> createQuery(Class<T> paramClass);
/*      */ 
/*      */   public abstract CriteriaQuery<Tuple> createTupleQuery();
/*      */ 
/*      */   public abstract <T> CriteriaUpdate<T> createCriteriaUpdate(Class<T> paramClass);
/*      */ 
/*      */   public abstract <T> CriteriaDelete<T> createCriteriaDelete(Class<T> paramClass);
/*      */ 
/*      */   public abstract <Y> CompoundSelection<Y> construct(Class<Y> paramClass, Selection<?>[] paramArrayOfSelection);
/*      */ 
/*      */   public abstract CompoundSelection<Tuple> tuple(Selection<?>[] paramArrayOfSelection);
/*      */ 
/*      */   public abstract CompoundSelection<Object[]> array(Selection<?>[] paramArrayOfSelection);
/*      */ 
/*      */   public abstract Order asc(Expression<?> paramExpression);
/*      */ 
/*      */   public abstract Order desc(Expression<?> paramExpression);
/*      */ 
/*      */   public abstract <N extends Number> Expression<Double> avg(Expression<N> paramExpression);
/*      */ 
/*      */   public abstract <N extends Number> Expression<N> sum(Expression<N> paramExpression);
/*      */ 
/*      */   public abstract Expression<Long> sumAsLong(Expression<Integer> paramExpression);
/*      */ 
/*      */   public abstract Expression<Double> sumAsDouble(Expression<Float> paramExpression);
/*      */ 
/*      */   public abstract <N extends Number> Expression<N> max(Expression<N> paramExpression);
/*      */ 
/*      */   public abstract <N extends Number> Expression<N> min(Expression<N> paramExpression);
/*      */ 
/*      */   public abstract <X extends Comparable<? super X>> Expression<X> greatest(Expression<X> paramExpression);
/*      */ 
/*      */   public abstract <X extends Comparable<? super X>> Expression<X> least(Expression<X> paramExpression);
/*      */ 
/*      */   public abstract Expression<Long> count(Expression<?> paramExpression);
/*      */ 
/*      */   public abstract Expression<Long> countDistinct(Expression<?> paramExpression);
/*      */ 
/*      */   public abstract Predicate exists(Subquery<?> paramSubquery);
/*      */ 
/*      */   public abstract <Y> Expression<Y> all(Subquery<Y> paramSubquery);
/*      */ 
/*      */   public abstract <Y> Expression<Y> some(Subquery<Y> paramSubquery);
/*      */ 
/*      */   public abstract <Y> Expression<Y> any(Subquery<Y> paramSubquery);
/*      */ 
/*      */   public abstract Predicate and(Expression<Boolean> paramExpression1, Expression<Boolean> paramExpression2);
/*      */ 
/*      */   public abstract Predicate and(Predicate[] paramArrayOfPredicate);
/*      */ 
/*      */   public abstract Predicate or(Expression<Boolean> paramExpression1, Expression<Boolean> paramExpression2);
/*      */ 
/*      */   public abstract Predicate or(Predicate[] paramArrayOfPredicate);
/*      */ 
/*      */   public abstract Predicate not(Expression<Boolean> paramExpression);
/*      */ 
/*      */   public abstract Predicate conjunction();
/*      */ 
/*      */   public abstract Predicate disjunction();
/*      */ 
/*      */   public abstract Predicate isTrue(Expression<Boolean> paramExpression);
/*      */ 
/*      */   public abstract Predicate isFalse(Expression<Boolean> paramExpression);
/*      */ 
/*      */   public abstract Predicate isNull(Expression<?> paramExpression);
/*      */ 
/*      */   public abstract Predicate isNotNull(Expression<?> paramExpression);
/*      */ 
/*      */   public abstract Predicate equal(Expression<?> paramExpression1, Expression<?> paramExpression2);
/*      */ 
/*      */   public abstract Predicate equal(Expression<?> paramExpression, Object paramObject);
/*      */ 
/*      */   public abstract Predicate notEqual(Expression<?> paramExpression1, Expression<?> paramExpression2);
/*      */ 
/*      */   public abstract Predicate notEqual(Expression<?> paramExpression, Object paramObject);
/*      */ 
/*      */   public abstract <Y extends Comparable<? super Y>> Predicate greaterThan(Expression<? extends Y> paramExpression1, Expression<? extends Y> paramExpression2);
/*      */ 
/*      */   public abstract <Y extends Comparable<? super Y>> Predicate greaterThan(Expression<? extends Y> paramExpression, Y paramY);
/*      */ 
/*      */   public abstract <Y extends Comparable<? super Y>> Predicate greaterThanOrEqualTo(Expression<? extends Y> paramExpression1, Expression<? extends Y> paramExpression2);
/*      */ 
/*      */   public abstract <Y extends Comparable<? super Y>> Predicate greaterThanOrEqualTo(Expression<? extends Y> paramExpression, Y paramY);
/*      */ 
/*      */   public abstract <Y extends Comparable<? super Y>> Predicate lessThan(Expression<? extends Y> paramExpression1, Expression<? extends Y> paramExpression2);
/*      */ 
/*      */   public abstract <Y extends Comparable<? super Y>> Predicate lessThan(Expression<? extends Y> paramExpression, Y paramY);
/*      */ 
/*      */   public abstract <Y extends Comparable<? super Y>> Predicate lessThanOrEqualTo(Expression<? extends Y> paramExpression1, Expression<? extends Y> paramExpression2);
/*      */ 
/*      */   public abstract <Y extends Comparable<? super Y>> Predicate lessThanOrEqualTo(Expression<? extends Y> paramExpression, Y paramY);
/*      */ 
/*      */   public abstract <Y extends Comparable<? super Y>> Predicate between(Expression<? extends Y> paramExpression1, Expression<? extends Y> paramExpression2, Expression<? extends Y> paramExpression3);
/*      */ 
/*      */   public abstract <Y extends Comparable<? super Y>> Predicate between(Expression<? extends Y> paramExpression, Y paramY1, Y paramY2);
/*      */ 
/*      */   public abstract Predicate gt(Expression<? extends Number> paramExpression1, Expression<? extends Number> paramExpression2);
/*      */ 
/*      */   public abstract Predicate gt(Expression<? extends Number> paramExpression, Number paramNumber);
/*      */ 
/*      */   public abstract Predicate ge(Expression<? extends Number> paramExpression1, Expression<? extends Number> paramExpression2);
/*      */ 
/*      */   public abstract Predicate ge(Expression<? extends Number> paramExpression, Number paramNumber);
/*      */ 
/*      */   public abstract Predicate lt(Expression<? extends Number> paramExpression1, Expression<? extends Number> paramExpression2);
/*      */ 
/*      */   public abstract Predicate lt(Expression<? extends Number> paramExpression, Number paramNumber);
/*      */ 
/*      */   public abstract Predicate le(Expression<? extends Number> paramExpression1, Expression<? extends Number> paramExpression2);
/*      */ 
/*      */   public abstract Predicate le(Expression<? extends Number> paramExpression, Number paramNumber);
/*      */ 
/*      */   public abstract <N extends Number> Expression<N> neg(Expression<N> paramExpression);
/*      */ 
/*      */   public abstract <N extends Number> Expression<N> abs(Expression<N> paramExpression);
/*      */ 
/*      */   public abstract <N extends Number> Expression<N> sum(Expression<? extends N> paramExpression1, Expression<? extends N> paramExpression2);
/*      */ 
/*      */   public abstract <N extends Number> Expression<N> sum(Expression<? extends N> paramExpression, N paramN);
/*      */ 
/*      */   public abstract <N extends Number> Expression<N> sum(N paramN, Expression<? extends N> paramExpression);
/*      */ 
/*      */   public abstract <N extends Number> Expression<N> prod(Expression<? extends N> paramExpression1, Expression<? extends N> paramExpression2);
/*      */ 
/*      */   public abstract <N extends Number> Expression<N> prod(Expression<? extends N> paramExpression, N paramN);
/*      */ 
/*      */   public abstract <N extends Number> Expression<N> prod(N paramN, Expression<? extends N> paramExpression);
/*      */ 
/*      */   public abstract <N extends Number> Expression<N> diff(Expression<? extends N> paramExpression1, Expression<? extends N> paramExpression2);
/*      */ 
/*      */   public abstract <N extends Number> Expression<N> diff(Expression<? extends N> paramExpression, N paramN);
/*      */ 
/*      */   public abstract <N extends Number> Expression<N> diff(N paramN, Expression<? extends N> paramExpression);
/*      */ 
/*      */   public abstract Expression<Number> quot(Expression<? extends Number> paramExpression1, Expression<? extends Number> paramExpression2);
/*      */ 
/*      */   public abstract Expression<Number> quot(Expression<? extends Number> paramExpression, Number paramNumber);
/*      */ 
/*      */   public abstract Expression<Number> quot(Number paramNumber, Expression<? extends Number> paramExpression);
/*      */ 
/*      */   public abstract Expression<Integer> mod(Expression<Integer> paramExpression1, Expression<Integer> paramExpression2);
/*      */ 
/*      */   public abstract Expression<Integer> mod(Expression<Integer> paramExpression, Integer paramInteger);
/*      */ 
/*      */   public abstract Expression<Integer> mod(Integer paramInteger, Expression<Integer> paramExpression);
/*      */ 
/*      */   public abstract Expression<Double> sqrt(Expression<? extends Number> paramExpression);
/*      */ 
/*      */   public abstract Expression<Long> toLong(Expression<? extends Number> paramExpression);
/*      */ 
/*      */   public abstract Expression<Integer> toInteger(Expression<? extends Number> paramExpression);
/*      */ 
/*      */   public abstract Expression<Float> toFloat(Expression<? extends Number> paramExpression);
/*      */ 
/*      */   public abstract Expression<Double> toDouble(Expression<? extends Number> paramExpression);
/*      */ 
/*      */   public abstract Expression<BigDecimal> toBigDecimal(Expression<? extends Number> paramExpression);
/*      */ 
/*      */   public abstract Expression<BigInteger> toBigInteger(Expression<? extends Number> paramExpression);
/*      */ 
/*      */   public abstract Expression<String> toString(Expression<Character> paramExpression);
/*      */ 
/*      */   public abstract <T> Expression<T> literal(T paramT);
/*      */ 
/*      */   public abstract <T> Expression<T> nullLiteral(Class<T> paramClass);
/*      */ 
/*      */   public abstract <T> ParameterExpression<T> parameter(Class<T> paramClass);
/*      */ 
/*      */   public abstract <T> ParameterExpression<T> parameter(Class<T> paramClass, String paramString);
/*      */ 
/*      */   public abstract <C extends Collection<?>> Predicate isEmpty(Expression<C> paramExpression);
/*      */ 
/*      */   public abstract <C extends Collection<?>> Predicate isNotEmpty(Expression<C> paramExpression);
/*      */ 
/*      */   public abstract <C extends Collection<?>> Expression<Integer> size(Expression<C> paramExpression);
/*      */ 
/*      */   public abstract <C extends Collection<?>> Expression<Integer> size(C paramC);
/*      */ 
/*      */   public abstract <E, C extends Collection<E>> Predicate isMember(Expression<E> paramExpression, Expression<C> paramExpression1);
/*      */ 
/*      */   public abstract <E, C extends Collection<E>> Predicate isMember(E paramE, Expression<C> paramExpression);
/*      */ 
/*      */   public abstract <E, C extends Collection<E>> Predicate isNotMember(Expression<E> paramExpression, Expression<C> paramExpression1);
/*      */ 
/*      */   public abstract <E, C extends Collection<E>> Predicate isNotMember(E paramE, Expression<C> paramExpression);
/*      */ 
/*      */   public abstract <V, M extends Map<?, V>> Expression<Collection<V>> values(M paramM);
/*      */ 
/*      */   public abstract <K, M extends Map<K, ?>> Expression<Set<K>> keys(M paramM);
/*      */ 
/*      */   public abstract Predicate like(Expression<String> paramExpression1, Expression<String> paramExpression2);
/*      */ 
/*      */   public abstract Predicate like(Expression<String> paramExpression, String paramString);
/*      */ 
/*      */   public abstract Predicate like(Expression<String> paramExpression1, Expression<String> paramExpression2, Expression<Character> paramExpression);
/*      */ 
/*      */   public abstract Predicate like(Expression<String> paramExpression1, Expression<String> paramExpression2, char paramChar);
/*      */ 
/*      */   public abstract Predicate like(Expression<String> paramExpression, String paramString, Expression<Character> paramExpression1);
/*      */ 
/*      */   public abstract Predicate like(Expression<String> paramExpression, String paramString, char paramChar);
/*      */ 
/*      */   public abstract Predicate notLike(Expression<String> paramExpression1, Expression<String> paramExpression2);
/*      */ 
/*      */   public abstract Predicate notLike(Expression<String> paramExpression, String paramString);
/*      */ 
/*      */   public abstract Predicate notLike(Expression<String> paramExpression1, Expression<String> paramExpression2, Expression<Character> paramExpression);
/*      */ 
/*      */   public abstract Predicate notLike(Expression<String> paramExpression1, Expression<String> paramExpression2, char paramChar);
/*      */ 
/*      */   public abstract Predicate notLike(Expression<String> paramExpression, String paramString, Expression<Character> paramExpression1);
/*      */ 
/*      */   public abstract Predicate notLike(Expression<String> paramExpression, String paramString, char paramChar);
/*      */ 
/*      */   public abstract Expression<String> concat(Expression<String> paramExpression1, Expression<String> paramExpression2);
/*      */ 
/*      */   public abstract Expression<String> concat(Expression<String> paramExpression, String paramString);
/*      */ 
/*      */   public abstract Expression<String> concat(String paramString, Expression<String> paramExpression);
/*      */ 
/*      */   public abstract Expression<String> substring(Expression<String> paramExpression, Expression<Integer> paramExpression1);
/*      */ 
/*      */   public abstract Expression<String> substring(Expression<String> paramExpression, int paramInt);
/*      */ 
/*      */   public abstract Expression<String> substring(Expression<String> paramExpression, Expression<Integer> paramExpression1, Expression<Integer> paramExpression2);
/*      */ 
/*      */   public abstract Expression<String> substring(Expression<String> paramExpression, int paramInt1, int paramInt2);
/*      */ 
/*      */   public abstract Expression<String> trim(Expression<String> paramExpression);
/*      */ 
/*      */   public abstract Expression<String> trim(Trimspec paramTrimspec, Expression<String> paramExpression);
/*      */ 
/*      */   public abstract Expression<String> trim(Expression<Character> paramExpression, Expression<String> paramExpression1);
/*      */ 
/*      */   public abstract Expression<String> trim(Trimspec paramTrimspec, Expression<Character> paramExpression, Expression<String> paramExpression1);
/*      */ 
/*      */   public abstract Expression<String> trim(char paramChar, Expression<String> paramExpression);
/*      */ 
/*      */   public abstract Expression<String> trim(Trimspec paramTrimspec, char paramChar, Expression<String> paramExpression);
/*      */ 
/*      */   public abstract Expression<String> lower(Expression<String> paramExpression);
/*      */ 
/*      */   public abstract Expression<String> upper(Expression<String> paramExpression);
/*      */ 
/*      */   public abstract Expression<Integer> length(Expression<String> paramExpression);
/*      */ 
/*      */   public abstract Expression<Integer> locate(Expression<String> paramExpression1, Expression<String> paramExpression2);
/*      */ 
/*      */   public abstract Expression<Integer> locate(Expression<String> paramExpression, String paramString);
/*      */ 
/*      */   public abstract Expression<Integer> locate(Expression<String> paramExpression1, Expression<String> paramExpression2, Expression<Integer> paramExpression);
/*      */ 
/*      */   public abstract Expression<Integer> locate(Expression<String> paramExpression, String paramString, int paramInt);
/*      */ 
/*      */   public abstract Expression<Date> currentDate();
/*      */ 
/*      */   public abstract Expression<Timestamp> currentTimestamp();
/*      */ 
/*      */   public abstract Expression<Time> currentTime();
/*      */ 
/*      */   public abstract <T> In<T> in(Expression<? extends T> paramExpression);
/*      */ 
/*      */   public abstract <Y> Expression<Y> coalesce(Expression<? extends Y> paramExpression1, Expression<? extends Y> paramExpression2);
/*      */ 
/*      */   public abstract <Y> Expression<Y> coalesce(Expression<? extends Y> paramExpression, Y paramY);
/*      */ 
/*      */   public abstract <Y> Expression<Y> nullif(Expression<Y> paramExpression, Expression<?> paramExpression1);
/*      */ 
/*      */   public abstract <Y> Expression<Y> nullif(Expression<Y> paramExpression, Y paramY);
/*      */ 
/*      */   public abstract <T> Coalesce<T> coalesce();
/*      */ 
/*      */   public abstract <C, R> SimpleCase<C, R> selectCase(Expression<? extends C> paramExpression);
/*      */ 
/*      */   public abstract <R> Case<R> selectCase();
/*      */ 
/*      */   public abstract <T> Expression<T> function(String paramString, Class<T> paramClass, Expression<?>[] paramArrayOfExpression);
/*      */ 
/*      */   public abstract <X, T, V extends T> Join<X, V> treat(Join<X, T> paramJoin, Class<V> paramClass);
/*      */ 
/*      */   public abstract <X, T, E extends T> CollectionJoin<X, E> treat(CollectionJoin<X, T> paramCollectionJoin, Class<E> paramClass);
/*      */ 
/*      */   public abstract <X, T, E extends T> SetJoin<X, E> treat(SetJoin<X, T> paramSetJoin, Class<E> paramClass);
/*      */ 
/*      */   public abstract <X, T, E extends T> ListJoin<X, E> treat(ListJoin<X, T> paramListJoin, Class<E> paramClass);
/*      */ 
/*      */   public abstract <X, K, T, V extends T> MapJoin<X, K, V> treat(MapJoin<X, K, T> paramMapJoin, Class<V> paramClass);
/*      */ 
/*      */   public abstract <X, T extends X> Path<T> treat(Path<X> paramPath, Class<T> paramClass);
/*      */ 
/*      */   public abstract <X, T extends X> Root<T> treat(Root<X> paramRoot, Class<T> paramClass);
/*      */ 
/*      */   public static abstract interface Case<R> extends Expression<R>
/*      */   {
/*      */     public abstract Case<R> when(Expression<Boolean> paramExpression, R paramR);
/*      */ 
/*      */     public abstract Case<R> when(Expression<Boolean> paramExpression, Expression<? extends R> paramExpression1);
/*      */ 
/*      */     public abstract Expression<R> otherwise(R paramR);
/*      */ 
/*      */     public abstract Expression<R> otherwise(Expression<? extends R> paramExpression);
/*      */   }
/*      */ 
/*      */   public static abstract interface SimpleCase<C, R> extends Expression<R>
/*      */   {
/*      */     public abstract Expression<C> getExpression();
/*      */ 
/*      */     public abstract SimpleCase<C, R> when(C paramC, R paramR);
/*      */ 
/*      */     public abstract SimpleCase<C, R> when(C paramC, Expression<? extends R> paramExpression);
/*      */ 
/*      */     public abstract Expression<R> otherwise(R paramR);
/*      */ 
/*      */     public abstract Expression<R> otherwise(Expression<? extends R> paramExpression);
/*      */   }
/*      */ 
/*      */   public static abstract interface Coalesce<T> extends Expression<T>
/*      */   {
/*      */     public abstract Coalesce<T> value(T paramT);
/*      */ 
/*      */     public abstract Coalesce<T> value(Expression<? extends T> paramExpression);
/*      */   }
/*      */ 
/*      */   public static abstract interface In<T> extends Predicate
/*      */   {
/*      */     public abstract Expression<T> getExpression();
/*      */ 
/*      */     public abstract In<T> value(T paramT);
/*      */ 
/*      */     public abstract In<T> value(Expression<? extends T> paramExpression);
/*      */   }
/*      */ 
/*      */   public static enum Trimspec
/*      */   {
/* 1300 */     LEADING, 
/*      */ 
/* 1305 */     TRAILING, 
/*      */ 
/* 1310 */     BOTH;
/*      */   }
/*      */ }

/* Location:           C:\Users\Administrator\Downloads\-hibernate-release-4.3.8.Final\hibernate-release-4.3.8.Final\lib\required\hibernate-jpa-2.1-api-1.0.0.Final.jar
 * Qualified Name:     javax.persistence.criteria.CriteriaBuilder
 * JD-Core Version:    0.6.2
 */
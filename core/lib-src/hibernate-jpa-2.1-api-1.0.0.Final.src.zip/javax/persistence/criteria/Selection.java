package javax.persistence.criteria;

import java.util.List;
import javax.persistence.TupleElement;

public abstract interface Selection<X> extends TupleElement<X>
{
  public abstract Selection<X> alias(String paramString);

  public abstract boolean isCompoundSelection();

  public abstract List<Selection<?>> getCompoundSelectionItems();
}

/* Location:           C:\Users\Administrator\Downloads\-hibernate-release-4.3.8.Final\hibernate-release-4.3.8.Final\lib\required\hibernate-jpa-2.1-api-1.0.0.Final.jar
 * Qualified Name:     javax.persistence.criteria.Selection
 * JD-Core Version:    0.6.2
 */
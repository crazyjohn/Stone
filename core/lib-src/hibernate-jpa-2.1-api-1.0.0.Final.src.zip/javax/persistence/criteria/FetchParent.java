package javax.persistence.criteria;

import java.util.Set;
import javax.persistence.metamodel.PluralAttribute;
import javax.persistence.metamodel.SingularAttribute;

public abstract interface FetchParent<Z, X>
{
  public abstract Set<Fetch<X, ?>> getFetches();

  public abstract <Y> Fetch<X, Y> fetch(SingularAttribute<? super X, Y> paramSingularAttribute);

  public abstract <Y> Fetch<X, Y> fetch(SingularAttribute<? super X, Y> paramSingularAttribute, JoinType paramJoinType);

  public abstract <Y> Fetch<X, Y> fetch(PluralAttribute<? super X, ?, Y> paramPluralAttribute);

  public abstract <Y> Fetch<X, Y> fetch(PluralAttribute<? super X, ?, Y> paramPluralAttribute, JoinType paramJoinType);

  public abstract <X, Y> Fetch<X, Y> fetch(String paramString);

  public abstract <X, Y> Fetch<X, Y> fetch(String paramString, JoinType paramJoinType);
}

/* Location:           C:\Users\Administrator\Downloads\-hibernate-release-4.3.8.Final\hibernate-release-4.3.8.Final\lib\required\hibernate-jpa-2.1-api-1.0.0.Final.jar
 * Qualified Name:     javax.persistence.criteria.FetchParent
 * JD-Core Version:    0.6.2
 */
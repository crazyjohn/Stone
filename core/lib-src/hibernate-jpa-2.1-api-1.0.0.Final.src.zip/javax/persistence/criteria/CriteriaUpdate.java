package javax.persistence.criteria;

import javax.persistence.metamodel.EntityType;
import javax.persistence.metamodel.SingularAttribute;

public abstract interface CriteriaUpdate<T> extends CommonAbstractCriteria
{
  public abstract Root<T> from(Class<T> paramClass);

  public abstract Root<T> from(EntityType<T> paramEntityType);

  public abstract Root<T> getRoot();

  public abstract <Y, X extends Y> CriteriaUpdate<T> set(SingularAttribute<? super T, Y> paramSingularAttribute, X paramX);

  public abstract <Y> CriteriaUpdate<T> set(SingularAttribute<? super T, Y> paramSingularAttribute, Expression<? extends Y> paramExpression);

  public abstract <Y, X extends Y> CriteriaUpdate<T> set(Path<Y> paramPath, X paramX);

  public abstract <Y> CriteriaUpdate<T> set(Path<Y> paramPath, Expression<? extends Y> paramExpression);

  public abstract CriteriaUpdate<T> set(String paramString, Object paramObject);

  public abstract CriteriaUpdate<T> where(Expression<Boolean> paramExpression);

  public abstract CriteriaUpdate<T> where(Predicate[] paramArrayOfPredicate);
}

/* Location:           C:\Users\Administrator\Downloads\-hibernate-release-4.3.8.Final\hibernate-release-4.3.8.Final\lib\required\hibernate-jpa-2.1-api-1.0.0.Final.jar
 * Qualified Name:     javax.persistence.criteria.CriteriaUpdate
 * JD-Core Version:    0.6.2
 */
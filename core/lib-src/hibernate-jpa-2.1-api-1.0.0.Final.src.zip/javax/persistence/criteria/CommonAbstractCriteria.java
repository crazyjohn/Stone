package javax.persistence.criteria;

public abstract interface CommonAbstractCriteria
{
  public abstract <U> Subquery<U> subquery(Class<U> paramClass);

  public abstract Predicate getRestriction();
}

/* Location:           C:\Users\Administrator\Downloads\-hibernate-release-4.3.8.Final\hibernate-release-4.3.8.Final\lib\required\hibernate-jpa-2.1-api-1.0.0.Final.jar
 * Qualified Name:     javax.persistence.criteria.CommonAbstractCriteria
 * JD-Core Version:    0.6.2
 */
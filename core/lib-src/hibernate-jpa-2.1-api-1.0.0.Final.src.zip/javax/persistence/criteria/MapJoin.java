package javax.persistence.criteria;

import java.util.Map;
import java.util.Map.Entry;
import javax.persistence.metamodel.MapAttribute;

public abstract interface MapJoin<Z, K, V> extends PluralJoin<Z, Map<K, V>, V>
{
  public abstract MapJoin<Z, K, V> on(Expression<Boolean> paramExpression);

  public abstract MapJoin<Z, K, V> on(Predicate[] paramArrayOfPredicate);

  public abstract MapAttribute<? super Z, K, V> getModel();

  public abstract Path<K> key();

  public abstract Path<V> value();

  public abstract Expression<Map.Entry<K, V>> entry();
}

/* Location:           C:\Users\Administrator\Downloads\-hibernate-release-4.3.8.Final\hibernate-release-4.3.8.Final\lib\required\hibernate-jpa-2.1-api-1.0.0.Final.jar
 * Qualified Name:     javax.persistence.criteria.MapJoin
 * JD-Core Version:    0.6.2
 */
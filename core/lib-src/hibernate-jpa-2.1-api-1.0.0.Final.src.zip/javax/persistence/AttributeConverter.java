package javax.persistence;

public abstract interface AttributeConverter<X, Y>
{
  public abstract Y convertToDatabaseColumn(X paramX);

  public abstract X convertToEntityAttribute(Y paramY);
}

/* Location:           C:\Users\Administrator\Downloads\-hibernate-release-4.3.8.Final\hibernate-release-4.3.8.Final\lib\required\hibernate-jpa-2.1-api-1.0.0.Final.jar
 * Qualified Name:     javax.persistence.AttributeConverter
 * JD-Core Version:    0.6.2
 */
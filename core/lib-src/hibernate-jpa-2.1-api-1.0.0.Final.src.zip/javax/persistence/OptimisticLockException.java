/*     */ package javax.persistence;
/*     */ 
/*     */ public class OptimisticLockException extends PersistenceException
/*     */ {
/*     */   Object entity;
/*     */ 
/*     */   public OptimisticLockException()
/*     */   {
/*     */   }
/*     */ 
/*     */   public OptimisticLockException(String message)
/*     */   {
/*  49 */     super(message);
/*     */   }
/*     */ 
/*     */   public OptimisticLockException(String message, Throwable cause)
/*     */   {
/*  62 */     super(message, cause);
/*     */   }
/*     */ 
/*     */   public OptimisticLockException(Throwable cause)
/*     */   {
/*  73 */     super(cause);
/*     */   }
/*     */ 
/*     */   public OptimisticLockException(Object entity)
/*     */   {
/*  84 */     this.entity = entity;
/*     */   }
/*     */ 
/*     */   public OptimisticLockException(String message, Throwable cause, Object entity)
/*     */   {
/*  99 */     super(message, cause);
/* 100 */     this.entity = entity;
/*     */   }
/*     */ 
/*     */   public Object getEntity()
/*     */   {
/* 109 */     return this.entity;
/*     */   }
/*     */ }

/* Location:           C:\Users\Administrator\Downloads\-hibernate-release-4.3.8.Final\hibernate-release-4.3.8.Final\lib\required\hibernate-jpa-2.1-api-1.0.0.Final.jar
 * Qualified Name:     javax.persistence.OptimisticLockException
 * JD-Core Version:    0.6.2
 */
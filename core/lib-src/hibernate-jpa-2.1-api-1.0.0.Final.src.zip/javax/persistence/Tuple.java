package javax.persistence;

import java.util.List;

public abstract interface Tuple
{
  public abstract <X> X get(TupleElement<X> paramTupleElement);

  public abstract <X> X get(String paramString, Class<X> paramClass);

  public abstract Object get(String paramString);

  public abstract <X> X get(int paramInt, Class<X> paramClass);

  public abstract Object get(int paramInt);

  public abstract Object[] toArray();

  public abstract List<TupleElement<?>> getElements();
}

/* Location:           C:\Users\Administrator\Downloads\-hibernate-release-4.3.8.Final\hibernate-release-4.3.8.Final\lib\required\hibernate-jpa-2.1-api-1.0.0.Final.jar
 * Qualified Name:     javax.persistence.Tuple
 * JD-Core Version:    0.6.2
 */
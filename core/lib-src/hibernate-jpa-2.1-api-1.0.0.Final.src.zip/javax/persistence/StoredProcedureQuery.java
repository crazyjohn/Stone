package javax.persistence;

import java.util.Calendar;
import java.util.Date;

public abstract interface StoredProcedureQuery extends Query
{
  public abstract StoredProcedureQuery setHint(String paramString, Object paramObject);

  public abstract <T> StoredProcedureQuery setParameter(Parameter<T> paramParameter, T paramT);

  public abstract StoredProcedureQuery setParameter(Parameter<Calendar> paramParameter, Calendar paramCalendar, TemporalType paramTemporalType);

  public abstract StoredProcedureQuery setParameter(Parameter<Date> paramParameter, Date paramDate, TemporalType paramTemporalType);

  public abstract StoredProcedureQuery setParameter(String paramString, Object paramObject);

  public abstract StoredProcedureQuery setParameter(String paramString, Calendar paramCalendar, TemporalType paramTemporalType);

  public abstract StoredProcedureQuery setParameter(String paramString, Date paramDate, TemporalType paramTemporalType);

  public abstract StoredProcedureQuery setParameter(int paramInt, Object paramObject);

  public abstract StoredProcedureQuery setParameter(int paramInt, Calendar paramCalendar, TemporalType paramTemporalType);

  public abstract StoredProcedureQuery setParameter(int paramInt, Date paramDate, TemporalType paramTemporalType);

  public abstract StoredProcedureQuery setFlushMode(FlushModeType paramFlushModeType);

  public abstract StoredProcedureQuery registerStoredProcedureParameter(int paramInt, Class paramClass, ParameterMode paramParameterMode);

  public abstract StoredProcedureQuery registerStoredProcedureParameter(String paramString, Class paramClass, ParameterMode paramParameterMode);

  public abstract Object getOutputParameterValue(int paramInt);

  public abstract Object getOutputParameterValue(String paramString);

  public abstract boolean execute();

  public abstract boolean hasMoreResults();

  public abstract int getUpdateCount();
}

/* Location:           C:\Users\Administrator\Downloads\-hibernate-release-4.3.8.Final\hibernate-release-4.3.8.Final\lib\required\hibernate-jpa-2.1-api-1.0.0.Final.jar
 * Qualified Name:     javax.persistence.StoredProcedureQuery
 * JD-Core Version:    0.6.2
 */
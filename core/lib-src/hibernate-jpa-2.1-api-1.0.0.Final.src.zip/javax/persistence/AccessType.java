/*    */ package javax.persistence;
/*    */ 
/*    */ public enum AccessType
/*    */ {
/* 24 */   FIELD, 
/*    */ 
/* 27 */   PROPERTY;
/*    */ }

/* Location:           C:\Users\Administrator\Downloads\-hibernate-release-4.3.8.Final\hibernate-release-4.3.8.Final\lib\required\hibernate-jpa-2.1-api-1.0.0.Final.jar
 * Qualified Name:     javax.persistence.AccessType
 * JD-Core Version:    0.6.2
 */
/*    */ package javax.persistence.spi;
/*    */ 
/*    */ public enum LoadState
/*    */ {
/* 21 */   LOADED, 
/*    */ 
/* 25 */   NOT_LOADED, 
/*    */ 
/* 29 */   UNKNOWN;
/*    */ }

/* Location:           C:\Users\Administrator\Downloads\-hibernate-release-4.3.8.Final\hibernate-release-4.3.8.Final\lib\required\hibernate-jpa-2.1-api-1.0.0.Final.jar
 * Qualified Name:     javax.persistence.spi.LoadState
 * JD-Core Version:    0.6.2
 */
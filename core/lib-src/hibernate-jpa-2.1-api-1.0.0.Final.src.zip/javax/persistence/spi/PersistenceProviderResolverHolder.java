/*     */ package javax.persistence.spi;
/*     */ 
/*     */ import java.io.BufferedReader;
/*     */ import java.io.IOException;
/*     */ import java.io.InputStream;
/*     */ import java.io.InputStreamReader;
/*     */ import java.lang.ref.WeakReference;
/*     */ import java.net.URL;
/*     */ import java.util.ArrayList;
/*     */ import java.util.Enumeration;
/*     */ import java.util.HashSet;
/*     */ import java.util.List;
/*     */ import java.util.Set;
/*     */ import java.util.WeakHashMap;
/*     */ import java.util.regex.Matcher;
/*     */ import java.util.regex.Pattern;
/*     */ import javax.persistence.PersistenceException;
/*     */ 
/*     */ public class PersistenceProviderResolverHolder
/*     */ {
/*  36 */   private static final PersistenceProviderResolver DEFAULT_RESOLVER = new PersistenceProviderResolverPerClassLoader(null);
/*     */   private static volatile PersistenceProviderResolver RESOLVER;
/*     */ 
/*     */   public static PersistenceProviderResolver getPersistenceProviderResolver()
/*     */   {
/*  46 */     return RESOLVER == null ? DEFAULT_RESOLVER : RESOLVER;
/*     */   }
/*     */ 
/*     */   public static void setPersistenceProviderResolver(PersistenceProviderResolver resolver)
/*     */   {
/*  55 */     RESOLVER = resolver;
/*     */   }
/*     */ 
/*     */   private static class PersistenceProviderResolverPerClassLoader
/*     */     implements PersistenceProviderResolver
/*     */   {
/*     */     private final WeakHashMap<ClassLoader, PersistenceProviderResolver> resolvers;
/*     */     private volatile short barrier;
/*     */ 
/*     */     private PersistenceProviderResolverPerClassLoader()
/*     */     {
/*  68 */       this.resolvers = new WeakHashMap();
/*     */ 
/*  70 */       this.barrier = 1;
/*     */     }
/*     */ 
/*     */     public List<PersistenceProvider> getPersistenceProviders()
/*     */     {
/*  76 */       ClassLoader cl = getContextualClassLoader();
/*  77 */       if (this.barrier == 1);
/*  78 */       PersistenceProviderResolver currentResolver = (PersistenceProviderResolver)this.resolvers.get(cl);
/*  79 */       if (currentResolver == null) {
/*  80 */         currentResolver = new CachingPersistenceProviderResolver(cl);
/*  81 */         this.resolvers.put(cl, currentResolver);
/*  82 */         this.barrier = 1;
/*     */       }
/*  84 */       return currentResolver.getPersistenceProviders();
/*     */     }
/*     */ 
/*     */     public void clearCachedProviders()
/*     */     {
/*  92 */       ClassLoader cl = getContextualClassLoader();
/*  93 */       if (this.barrier == 1);
/*  94 */       PersistenceProviderResolver currentResolver = (PersistenceProviderResolver)this.resolvers.get(cl);
/*  95 */       if (currentResolver != null)
/*  96 */         currentResolver.clearCachedProviders();
/*     */     }
/*     */ 
/*     */     private static ClassLoader getContextualClassLoader()
/*     */     {
/* 101 */       ClassLoader cl = Thread.currentThread().getContextClassLoader();
/* 102 */       if (cl == null) {
/* 103 */         cl = PersistenceProviderResolverPerClassLoader.class.getClassLoader();
/*     */       }
/* 105 */       return cl;
/*     */     }
/*     */ 
/*     */     private static class CachingPersistenceProviderResolver
/*     */       implements PersistenceProviderResolver
/*     */     {
/* 118 */       private final List<WeakReference<Class<? extends PersistenceProvider>>> resolverClasses = new ArrayList();
/*     */ 
/* 201 */       private static final Pattern nonCommentPattern = Pattern.compile("^([^#]+)");
/*     */ 
/*     */       public CachingPersistenceProviderResolver(ClassLoader cl)
/*     */       {
/* 122 */         loadResolverClasses(cl);
/*     */       }
/*     */ 
/*     */       private void loadResolverClasses(ClassLoader cl) {
/* 126 */         synchronized (this.resolverClasses) {
/*     */           try {
/* 128 */             Enumeration resources = cl.getResources("META-INF/services/" + PersistenceProvider.class.getName());
/* 129 */             Set names = new HashSet();
/* 130 */             while (resources.hasMoreElements()) {
/* 131 */               URL url = (URL)resources.nextElement();
/* 132 */               InputStream is = url.openStream();
/*     */               try {
/* 134 */                 names.addAll(providerNamesFromReader(new BufferedReader(new InputStreamReader(is))));
/*     */               }
/*     */               finally {
/* 137 */                 is.close();
/*     */               }
/*     */             }
/* 140 */             for (String s : names)
/*     */             {
/* 142 */               Class providerClass = cl.loadClass(s);
/* 143 */               WeakReference reference = new WeakReference(providerClass);
/*     */ 
/* 146 */               if ((s.endsWith("HibernatePersistence")) && (this.resolverClasses.size() > 0)) {
/* 147 */                 WeakReference movedReference = (WeakReference)this.resolverClasses.get(0);
/* 148 */                 this.resolverClasses.add(0, reference);
/* 149 */                 this.resolverClasses.add(movedReference);
/*     */               }
/*     */               else {
/* 152 */                 this.resolverClasses.add(reference);
/*     */               }
/*     */             }
/*     */           }
/*     */           catch (IOException e) {
/* 157 */             throw new PersistenceException(e);
/*     */           }
/*     */           catch (ClassNotFoundException e) {
/* 160 */             throw new PersistenceException(e);
/*     */           }
/*     */         }
/*     */       }
/*     */ 
/*     */       public List<PersistenceProvider> getPersistenceProviders()
/*     */       {
/* 173 */         synchronized (this.resolverClasses) {
/* 174 */           List providers = new ArrayList(this.resolverClasses.size());
/*     */           try {
/* 176 */             for (WeakReference providerClass : this.resolverClasses)
/* 177 */               providers.add(((Class)providerClass.get()).newInstance());
/*     */           }
/*     */           catch (InstantiationException e)
/*     */           {
/* 181 */             throw new PersistenceException(e);
/*     */           }
/*     */           catch (IllegalAccessException e) {
/* 184 */             throw new PersistenceException(e);
/*     */           }
/* 186 */           return providers;
/*     */         }
/*     */       }
/*     */ 
/*     */       public synchronized void clearCachedProviders()
/*     */       {
/* 194 */         synchronized (this.resolverClasses) {
/* 195 */           this.resolverClasses.clear();
/* 196 */           loadResolverClasses(PersistenceProviderResolverHolder.PersistenceProviderResolverPerClassLoader.access$100());
/*     */         }
/*     */       }
/*     */ 
/*     */       private static Set<String> providerNamesFromReader(BufferedReader reader)
/*     */         throws IOException
/*     */       {
/* 204 */         Set names = new HashSet();
/*     */         String line;
/* 206 */         while ((line = reader.readLine()) != null) {
/* 207 */           line = line.trim();
/* 208 */           Matcher m = nonCommentPattern.matcher(line);
/* 209 */           if (m.find()) {
/* 210 */             names.add(m.group().trim());
/*     */           }
/*     */         }
/* 213 */         return names;
/*     */       }
/*     */     }
/*     */   }
/*     */ }

/* Location:           C:\Users\Administrator\Downloads\-hibernate-release-4.3.8.Final\hibernate-release-4.3.8.Final\lib\required\hibernate-jpa-2.1-api-1.0.0.Final.jar
 * Qualified Name:     javax.persistence.spi.PersistenceProviderResolverHolder
 * JD-Core Version:    0.6.2
 */
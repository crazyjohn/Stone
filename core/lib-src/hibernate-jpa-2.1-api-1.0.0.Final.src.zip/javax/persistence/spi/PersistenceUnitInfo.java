package javax.persistence.spi;

import java.net.URL;
import java.util.List;
import java.util.Properties;
import javax.persistence.SharedCacheMode;
import javax.persistence.ValidationMode;
import javax.sql.DataSource;

public abstract interface PersistenceUnitInfo
{
  public abstract String getPersistenceUnitName();

  public abstract String getPersistenceProviderClassName();

  public abstract PersistenceUnitTransactionType getTransactionType();

  public abstract DataSource getJtaDataSource();

  public abstract DataSource getNonJtaDataSource();

  public abstract List<String> getMappingFileNames();

  public abstract List<URL> getJarFileUrls();

  public abstract URL getPersistenceUnitRootUrl();

  public abstract List<String> getManagedClassNames();

  public abstract boolean excludeUnlistedClasses();

  public abstract SharedCacheMode getSharedCacheMode();

  public abstract ValidationMode getValidationMode();

  public abstract Properties getProperties();

  public abstract String getPersistenceXMLSchemaVersion();

  public abstract ClassLoader getClassLoader();

  public abstract void addTransformer(ClassTransformer paramClassTransformer);

  public abstract ClassLoader getNewTempClassLoader();
}

/* Location:           C:\Users\Administrator\Downloads\-hibernate-release-4.3.8.Final\hibernate-release-4.3.8.Final\lib\required\hibernate-jpa-2.1-api-1.0.0.Final.jar
 * Qualified Name:     javax.persistence.spi.PersistenceUnitInfo
 * JD-Core Version:    0.6.2
 */
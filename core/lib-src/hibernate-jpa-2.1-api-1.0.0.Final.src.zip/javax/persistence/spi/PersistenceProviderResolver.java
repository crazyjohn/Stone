package javax.persistence.spi;

import java.util.List;

public abstract interface PersistenceProviderResolver
{
  public abstract List<PersistenceProvider> getPersistenceProviders();

  public abstract void clearCachedProviders();
}

/* Location:           C:\Users\Administrator\Downloads\-hibernate-release-4.3.8.Final\hibernate-release-4.3.8.Final\lib\required\hibernate-jpa-2.1-api-1.0.0.Final.jar
 * Qualified Name:     javax.persistence.spi.PersistenceProviderResolver
 * JD-Core Version:    0.6.2
 */
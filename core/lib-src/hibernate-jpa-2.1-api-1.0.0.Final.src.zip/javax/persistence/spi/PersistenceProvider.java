package javax.persistence.spi;

import java.util.Map;
import javax.persistence.EntityManagerFactory;

public abstract interface PersistenceProvider
{
  public abstract EntityManagerFactory createEntityManagerFactory(String paramString, Map paramMap);

  public abstract EntityManagerFactory createContainerEntityManagerFactory(PersistenceUnitInfo paramPersistenceUnitInfo, Map paramMap);

  public abstract void generateSchema(PersistenceUnitInfo paramPersistenceUnitInfo, Map paramMap);

  public abstract boolean generateSchema(String paramString, Map paramMap);

  public abstract ProviderUtil getProviderUtil();
}

/* Location:           C:\Users\Administrator\Downloads\-hibernate-release-4.3.8.Final\hibernate-release-4.3.8.Final\lib\required\hibernate-jpa-2.1-api-1.0.0.Final.jar
 * Qualified Name:     javax.persistence.spi.PersistenceProvider
 * JD-Core Version:    0.6.2
 */
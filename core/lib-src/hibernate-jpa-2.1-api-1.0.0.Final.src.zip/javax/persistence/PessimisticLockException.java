/*    */ package javax.persistence;
/*    */ 
/*    */ public class PessimisticLockException extends PersistenceException
/*    */ {
/*    */   Object entity;
/*    */ 
/*    */   public PessimisticLockException()
/*    */   {
/*    */   }
/*    */ 
/*    */   public PessimisticLockException(String message)
/*    */   {
/* 41 */     super(message);
/*    */   }
/*    */ 
/*    */   public PessimisticLockException(String message, Throwable cause)
/*    */   {
/* 52 */     super(message, cause);
/*    */   }
/*    */ 
/*    */   public PessimisticLockException(Throwable cause)
/*    */   {
/* 62 */     super(cause);
/*    */   }
/*    */ 
/*    */   public PessimisticLockException(Object entity)
/*    */   {
/* 72 */     this.entity = entity;
/*    */   }
/*    */ 
/*    */   public PessimisticLockException(String message, Throwable cause, Object entity)
/*    */   {
/* 84 */     super(message, cause);
/* 85 */     this.entity = entity;
/*    */   }
/*    */ 
/*    */   public Object getEntity()
/*    */   {
/* 94 */     return this.entity;
/*    */   }
/*    */ }

/* Location:           C:\Users\Administrator\Downloads\-hibernate-release-4.3.8.Final\hibernate-release-4.3.8.Final\lib\required\hibernate-jpa-2.1-api-1.0.0.Final.jar
 * Qualified Name:     javax.persistence.PessimisticLockException
 * JD-Core Version:    0.6.2
 */
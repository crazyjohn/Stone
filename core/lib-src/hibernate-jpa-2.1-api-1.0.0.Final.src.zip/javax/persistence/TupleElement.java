package javax.persistence;

public abstract interface TupleElement<X>
{
  public abstract Class<? extends X> getJavaType();

  public abstract String getAlias();
}

/* Location:           C:\Users\Administrator\Downloads\-hibernate-release-4.3.8.Final\hibernate-release-4.3.8.Final\lib\required\hibernate-jpa-2.1-api-1.0.0.Final.jar
 * Qualified Name:     javax.persistence.TupleElement
 * JD-Core Version:    0.6.2
 */
package javax.persistence;

import java.util.Map;

public abstract interface AttributeNode<T>
{
  public abstract String getAttributeName();

  public abstract Map<Class, Subgraph> getSubgraphs();

  public abstract Map<Class, Subgraph> getKeySubgraphs();
}

/* Location:           C:\Users\Administrator\Downloads\-hibernate-release-4.3.8.Final\hibernate-release-4.3.8.Final\lib\required\hibernate-jpa-2.1-api-1.0.0.Final.jar
 * Qualified Name:     javax.persistence.AttributeNode
 * JD-Core Version:    0.6.2
 */
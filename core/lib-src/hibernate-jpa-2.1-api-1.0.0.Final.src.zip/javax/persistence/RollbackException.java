/*    */ package javax.persistence;
/*    */ 
/*    */ public class RollbackException extends PersistenceException
/*    */ {
/*    */   public RollbackException()
/*    */   {
/*    */   }
/*    */ 
/*    */   public RollbackException(String message)
/*    */   {
/* 35 */     super(message);
/*    */   }
/*    */ 
/*    */   public RollbackException(String message, Throwable cause)
/*    */   {
/* 46 */     super(message, cause);
/*    */   }
/*    */ 
/*    */   public RollbackException(Throwable cause)
/*    */   {
/* 56 */     super(cause);
/*    */   }
/*    */ }

/* Location:           C:\Users\Administrator\Downloads\-hibernate-release-4.3.8.Final\hibernate-release-4.3.8.Final\lib\required\hibernate-jpa-2.1-api-1.0.0.Final.jar
 * Qualified Name:     javax.persistence.RollbackException
 * JD-Core Version:    0.6.2
 */
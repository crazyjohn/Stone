/*    */ package com.sun.activation.registries;
/*    */ 
/*    */ public class MailcapParseException extends Exception
/*    */ {
/*    */   public MailcapParseException()
/*    */   {
/*    */   }
/*    */ 
/*    */   public MailcapParseException(String inInfo)
/*    */   {
/* 38 */     super(inInfo);
/*    */   }
/*    */ }

/* Location:           C:\Program Files\Java\jdk1.7.0_60\jre\lib\rt.jar
 * Qualified Name:     com.sun.activation.registries.MailcapParseException
 * JD-Core Version:    0.6.2
 */
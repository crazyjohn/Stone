/*    */ package com.sun.beans.decoder;
/*    */ 
/*    */ final class VoidElementHandler extends ObjectElementHandler
/*    */ {
/*    */   protected boolean isArgument()
/*    */   {
/* 66 */     return false;
/*    */   }
/*    */ }

/* Location:           C:\Program Files\Java\jdk1.7.0_60\jre\lib\rt.jar
 * Qualified Name:     com.sun.beans.decoder.VoidElementHandler
 * JD-Core Version:    0.6.2
 */
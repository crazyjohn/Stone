package com.sun.beans.decoder;

public abstract interface ValueObject
{
  public abstract Object getValue();

  public abstract boolean isVoid();
}

/* Location:           C:\Program Files\Java\jdk1.7.0_60\jre\lib\rt.jar
 * Qualified Name:     com.sun.beans.decoder.ValueObject
 * JD-Core Version:    0.6.2
 */
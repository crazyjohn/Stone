/*    */ package com.sun.beans.decoder;
/*    */ 
/*    */ final class TrueElementHandler extends NullElementHandler
/*    */ {
/*    */   public Object getValue()
/*    */   {
/* 54 */     return Boolean.TRUE;
/*    */   }
/*    */ }

/* Location:           C:\Program Files\Java\jdk1.7.0_60\jre\lib\rt.jar
 * Qualified Name:     com.sun.beans.decoder.TrueElementHandler
 * JD-Core Version:    0.6.2
 */
/*    */ package com.sun.corba.se.impl.protocol;
/*    */ 
/*    */ class NotExistent extends NonExistent
/*    */ {
/*    */   public String getName()
/*    */   {
/* 96 */     return "_not_existent";
/*    */   }
/*    */ }

/* Location:           C:\Program Files\Java\jdk1.7.0_60\jre\lib\rt.jar
 * Qualified Name:     com.sun.corba.se.impl.protocol.NotExistent
 * JD-Core Version:    0.6.2
 */
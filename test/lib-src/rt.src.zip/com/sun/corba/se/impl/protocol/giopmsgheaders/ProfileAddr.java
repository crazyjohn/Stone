package com.sun.corba.se.impl.protocol.giopmsgheaders;

public abstract interface ProfileAddr
{
  public static final short value = 1;
}

/* Location:           C:\Program Files\Java\jdk1.7.0_60\jre\lib\rt.jar
 * Qualified Name:     com.sun.corba.se.impl.protocol.giopmsgheaders.ProfileAddr
 * JD-Core Version:    0.6.2
 */
/*    */ package com.sun.corba.se.impl.copyobject;
/*    */ 
/*    */ import com.sun.corba.se.spi.copyobject.ObjectCopier;
/*    */ 
/*    */ public class ReferenceObjectCopierImpl
/*    */   implements ObjectCopier
/*    */ {
/*    */   public Object copy(Object paramObject)
/*    */   {
/* 34 */     return paramObject;
/*    */   }
/*    */ }

/* Location:           C:\Program Files\Java\jdk1.7.0_60\jre\lib\rt.jar
 * Qualified Name:     com.sun.corba.se.impl.copyobject.ReferenceObjectCopierImpl
 * JD-Core Version:    0.6.2
 */
/*    */ package com.sun.corba.se.impl.io;
/*    */ 
/*    */ public class TypeMismatchException extends Error
/*    */ {
/*    */   public TypeMismatchException()
/*    */   {
/*    */   }
/*    */ 
/*    */   public TypeMismatchException(String paramString)
/*    */   {
/* 43 */     super(paramString);
/*    */   }
/*    */ }

/* Location:           C:\Program Files\Java\jdk1.7.0_60\jre\lib\rt.jar
 * Qualified Name:     com.sun.corba.se.impl.io.TypeMismatchException
 * JD-Core Version:    0.6.2
 */
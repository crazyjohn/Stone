package com.sun.corba.se.impl.orbutil.graph;

import java.util.Set;

public abstract interface Node
{
  public abstract Set getChildren();
}

/* Location:           C:\Program Files\Java\jdk1.7.0_60\jre\lib\rt.jar
 * Qualified Name:     com.sun.corba.se.impl.orbutil.graph.Node
 * JD-Core Version:    0.6.2
 */
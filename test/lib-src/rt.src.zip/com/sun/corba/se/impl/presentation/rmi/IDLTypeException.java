/*    */ package com.sun.corba.se.impl.presentation.rmi;
/*    */ 
/*    */ public class IDLTypeException extends Exception
/*    */ {
/*    */   public IDLTypeException()
/*    */   {
/*    */   }
/*    */ 
/*    */   public IDLTypeException(String paramString)
/*    */   {
/* 37 */     super(paramString);
/*    */   }
/*    */ }

/* Location:           C:\Program Files\Java\jdk1.7.0_60\jre\lib\rt.jar
 * Qualified Name:     com.sun.corba.se.impl.presentation.rmi.IDLTypeException
 * JD-Core Version:    0.6.2
 */